package com.demo.interfaces;

public interface CompareInt {
	int findMax(int x,int y); 

}
