package com.demo.exceptions;

public class CourseNotFound extends Exception{
   public CourseNotFound(String msg) {
	   super(msg);
   }
}
