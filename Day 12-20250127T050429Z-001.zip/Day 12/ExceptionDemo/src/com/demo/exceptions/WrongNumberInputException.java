package com.demo.exceptions;

public class WrongNumberInputException extends Exception{
	public WrongNumberInputException(String msg) {
		super(msg);
	}

}
