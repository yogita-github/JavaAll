package com.demo.test;

public class TestStudentListCollection {

}
